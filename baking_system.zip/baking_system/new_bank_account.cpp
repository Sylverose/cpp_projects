			//BANK MANAGEMENT PROJECT
			
#include<stdio.h>
#include<conio.h>
#include<iostream>
using namespace std;
class bank
{
	char name[100], add[100],y;
	int balance;
	public:
		void open_account();
		void deposit_money();
		void withdraw_money();
		void display_account();
		};
void bank::open_account()
{
	cout<<"Enter your full name::";
	cin.ignore();
	cin.getline(name,100);
	cout<<"Enter your address::";
	cin.ignore();
	cin.getline(add,100);
	cout<<"What type of account do you want to open savings (s) or current (c) ";
	cin>>y;
	cout<<"Enter amount for deposit::";
	cin>> balance;
	cout<<"Your account is created.";
}
void bank::deposit_money()
	{	
		int a;
		cout<<"Enter amount::";
		cin>>a;
		balance+=a;
		cout<<"Total deposited amount:: \t"<<balance;
	}
void bank::display_account()
{
	cout<<"Your full name:: \t"<<name;
	cout<<"Your address:: \t"<<add;
	cout<<"Type of account:: \t"<<y;
	cout<<"Account balance:: \t"<<balance;
}
void bank::withdraw_money()
{
	float amount;
	cout<<"\n withdraw:: ";
	cout<<"enter amount::";	
	cin>>amount;
	balance-=amount;
	cout<<"Total after withdrawal:: "<<balance;	
}
int main()
{
	int option,x;
	bank obj;
	do{
	
	cout<<"1) Open account \n";
	cout<<"2) Deposit money \n";
	cout<<"3) Withdraw money \n";
	cout<<"4) Display account \n";
	cout<<"5) Exit \n";
	cout<<"Select an option from above \n";
	cin>>option;
	switch(option)
	{
		case 1: "1)Open account \n";
		obj.open_account();
		break;
		case 2: "2)Deposit money \n";
		obj.deposit_money();
		break;
		case 3: "3)Withdraw money \n";
		obj.withdraw_money();
		break;
		case 4: "4)Display account balance \n";
		obj.display_account();
		break;
		case 5:
			if(option==5)
			{
				exit(1);
			}
	default:
		cout<<"This option does not exist, try again. \n";
	}
	cout<<"\n To select the next option press::y \n";
	cout<<"To exit press:: N";
	x=getch();
	if(x=='n'||x=='N')
	exit(0);
}while(x=='y'||x=='Y');

	getch();
	return 0;
	
}
