#include<iostream>
#include<string>

using namespace std;

int main()
{
	string roomType;
	int numNights;
	double roomRate, total;
	
	cout<<"Welcome to the Hotel Management System"<<endl;
	cout<<"Please enter your room type: ";
	cin>>roomType;
	cout<<"Please enter the number of nights: ";
	cin>>numNights;
	cout<<"Insert room rate (in DKK): ";
	cin>>roomRate;
	
	total=numNights*roomRate;
	
	cout<<"Your stay at the room "<<roomType<<" for "<<numNights<<" nights at "<<roomRate<<" DKK per night, will be a total of "<<total<<" DKK."<<endl;
	cout<<"Would you be paying by card or cash?"<<endl;
	
	return 0;
}
